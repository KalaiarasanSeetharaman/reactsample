/***Importing Axios Lib for Async Method For Getting Data From Api***/

import * as axios from 'axios';

/***Api Url***/


const APP_URL = "http://api.openweathermap.org/data/2.5/weather";

export const getCityWeather = function(city,Api_Key){
      var requestUrl = `${APP_URL}?q=${city}&appid=${Api_Key}&units=metric`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (response) {
        return response;
      });
};