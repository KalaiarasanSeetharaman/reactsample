/***
Default State for this reducer will be {isLoading:false,lists: '',status: false,error: ''}
It will change when action trigger for changing the state
When state it will change the store also
List Reducer for Sending State to Store Whenever Action Trigger ***/

const weatherReducer = (state = {temperature:'', city: '',humidity: '', error: '',status:false  }, action) => {
  switch (action.type) {
    case 'SENDING_REQUEST':
      return { 
          ...state,
          status: false 
      };
    case 'RECEVIED_LISTS':
      return { 
          ...state,
          temperature: action.temperature,
          city: action.city,
          humidity: action.humidity,
          error: action.error,
          status: true
     };
     case 'SENDING_REQUEST_FAILED':
      return { 
          ...state,
          temperature: action.temperature,
          city: action.city,
          humidity: action.humidity,
          error: action.error,
          status: true
     };
    default:
      return state;
  };
}
export default weatherReducer;


