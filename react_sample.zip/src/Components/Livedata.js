import React, { Component } from 'react';
import { Card, CardBody,CardTitle, Button, Form, Input, Row, Col} from 'reactstrap';
import { connect } from 'react-redux';

import Liveweather from '../Components/Liveweather.js';
import Imagedisplay from '../Components/Imagedisplay.js';

import * as weatherAction  from '../actions';

const Api_Key = "815b458635e236ba582e62d1d0ffbf21";


  
class Livedata extends Component {
    constructor(props) {
        super(props);
        const { dispatch } = this.props;
        this.state = {
            temperature: '',
            city: '',
            humidity:'',
            error:''
        };

    }
    
    
    getHistoryWeather = async (e) => {
         const city = e.target.elements.city.value;
         e.preventDefault();
         const { dispatch } = this.props;
         dispatch(weatherAction.getWeatherForCity(city,Api_Key));
      }
render() {
      const { weatherdata  } = this.props;
      return (
        <div >
          <Card style={{height:"250px",marginTop:"12px"}}>
            <CardBody>
              <CardTitle>Current Data</CardTitle>
                <Form onSubmit = {this.getHistoryWeather}>
                  <Row form>
                    <Col md={6}>
                      <Input type="text" name="city" placeholder="Enter City" required/>     
                    </Col>
                    <Col md={6}>
                      <Button >Submit</Button>
                    </Col>
                  </Row>
                </Form>
            </CardBody>
            <Imagedisplay city={weatherdata.city}/>
            <Liveweather
              temperature={weatherdata.temperature}
              city={weatherdata.city}
              humidity={weatherdata.humidity}
              country={weatherdata.country}
              error={weatherdata.error}
              />
        
          </Card>
        </div>
  
      );
    }
  }

const mapStateToProps = state => {
  return {weatherdata: state.weatherReducer};
};

export default connect(mapStateToProps)(Livedata);