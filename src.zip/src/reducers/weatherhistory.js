const historyReducer = (state = {temperature:[], pressure:[],humidity:[], error:[],count:0,date:[],status:false  }, action) => {
    switch (action.type) {
      case 'SENDING_REQUEST':
        return { 
            ...state,
            temperature:[], pressure:[],humidity:[], error:[],count:0,date:[],
            status: false 
        };
      case 'RECEVIED_LISTS':
        return { 
            ...state,
            count:action.count,
            weatherhistoryData: action.weatherhistoryData,
            error: "",
            status: true
       };
       case 'SENDING_REQUEST_FAILED':
        return { 
            ...state,
            error: action.error,
            count: action.count,
            status: true
       };
      default:
        return state;
    };
  }
  export default historyReducer;
  