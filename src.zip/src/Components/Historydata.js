
import React, { Component } from 'react';
import '../Styles/App.css';
import { Table} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import PropTypes from 'prop-types';

class Historydata extends Component {
  render() {
    const {count} = this.props;
    return (
        <div>
            {(count>0) && <Table striped>
                    <thead>
                        <tr>
                            <th>Si No</th>
                            <th>Date</th>
                            <th>Temperature  &#8451;</th>
                            <th>Humidity</th>
                            <th>Pressure</th>
                        </tr>
                    </thead>
                    <tbody >
                    {this.props.Data.map((subitem, index) => {
                         return (
                            <tr key={index}>
                                <td>{index+1}</td>
                                <td>{subitem.dt_txt}</td>
                                <td>{subitem.main.temp}</td>
                                <td>{subitem.main.humidity}</td>
                                <td>{subitem.main.pressure}</td>
                            </tr>
                          )
                    })}
                        
                    </tbody>
                </Table>
            }
            {this.props.error && <p style={{color:"red", fontSize:20, textAlign:"center"}}>{this.props.error}</p>}
            </div>
    );
  }
}



export default Historydata;