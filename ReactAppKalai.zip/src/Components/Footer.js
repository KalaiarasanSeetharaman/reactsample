import React from 'react';
import '../Styles/App.css';

function Footer() {
  return (
      <div>
          <div className="footer">
              Copyright Info
          </div>
          
      </div> 
  )
}

export default Footer;