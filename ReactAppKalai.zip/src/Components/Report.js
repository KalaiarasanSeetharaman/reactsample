import React, { Component } from 'react';
import { connect } from 'react-redux';
import DatePicker from 'react-date-picker';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Form, Card, CardTitle, CardBody, Row, Col} from 'reactstrap';
import * as reportAction  from '../Actions/Report';
import Historydata from '../Components/Historydata.js';
import moment from 'moment';
const Api_Key = "815b458635e236ba582e62d1d0ffbf21";


class Report extends Component {

  constructor(props){
    super(props);
    this.state={
      startdate: new Date(),
      enddate: new Date(),
      temperature: [],
      pressure: [],
      humidity: [],
      error: [],
      count:0,
      date:[],
    }
 }

 componentDidMount(){
  const {dispatch} = this.props; 
  dispatch(reportAction.initateReport());
 }



  getWeather = async (e) => {
      const {dispatch} = this.props; 
      dispatch(reportAction.getReportWeather(Api_Key));
   }
 
  onStartChange = date => this.setState({startdate: date })
  onEndChange = date => this.setState({enddate: date })
 
  render() {
    const {weatherReportdata} =this.props;
    return (
      
      <div  className="maincontent">
       <h4>Weather Report</h4>
      <Card style={{height:"200px",marginTop:"12px"}}>
            <CardBody>
            <CardTitle>Report Data</CardTitle>
            <Form className="dateselector">
            <Row >
            <Col md={3} sm={6} xs={12}>
                Start Date: <DatePicker
                    onChange={this.onStartChange}
                    value={this.state.startdate}
                    calendarIcon=""
                    clearIcon=""
                  />
                </Col>
                <Col md={3} sm={6} xs={12}>
                End Date : <DatePicker
                    onChange={this.onEndChange}
                    value={this.state.enddate}
                    calendarIcon=""
                    clearIcon=""
                  />
                </Col>
                <Col md={3} sm={6} xs={12}>
                <Button data-toggle="tooltip" data-placement="top" title="Submit" onClick={this.getWeather}>Submit</Button>
                </Col>
                </Row>
            </Form>
    </CardBody>
    </Card>
    <Historydata
                          count = {weatherReportdata.count}
                          temperature={weatherReportdata.temperature}
                          pressure={weatherReportdata.pressure}
                          humidity={weatherReportdata.humidity}
                          error={weatherReportdata.error}
                          date={weatherReportdata.date}
                          Data={weatherReportdata.weatherhistoryData}
                          />

       
      </div>
    );
  }
}

const mapStateToProps = state =>{
  return {weatherReportdata: state.reportReducer};
}
export default connect(mapStateToProps)(Report);
