import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Card, CardBody,CardTitle, Button, Form, Input, Row, Col} from 'reactstrap';
import * as historyAction  from '../Actions/Weatherhistory';
import Historydata from '../Components/Historydata.js';
import '../Styles/App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
const Api_Key = "815b458635e236ba582e62d1d0ffbf21";

class History extends Component {
  constructor(props){
      super(props);
      this.state={
          temperature: [],
          pressure: [],
          humidity: [],
          error: [],
          count:0,
          date:[],
      }
   }

   componentDidMount(){
    const {dispatch} = this.props; 
    dispatch(historyAction.initateWeatherHistory());
   }

  getWeather = async (e) => {
        const city = e.target.elements.city.value;
        e.preventDefault();
        const {dispatch} = this.props; 
        dispatch(historyAction.getWeatherHistory(city,Api_Key));
  }
  render() {
    const { weatherhistorydata  } = this.props;
        return (
          <div  className="maincontent">
          <h4>Historic Weather </h4>
            <Card style={{height:"200px",marginTop:"12px"}}>
              <CardBody>
                <CardTitle>Historic Data</CardTitle>
                  <Form onSubmit = {this.getWeather}>
                    <Row form>
                      <Col md={6}>
                        <Input type="text" name="city" placeholder="Enter City" required/>     
                      </Col>
                      <Col md={6}>
                        <Button >Submit</Button>
                      </Col>
                    </Row>
                  </Form>
              </CardBody>
            </Card>
            <Historydata
              count = {weatherhistorydata.count}
              temperature={weatherhistorydata.temperature}
              pressure={weatherhistorydata.pressure}
              humidity={weatherhistorydata.humidity}
              error={weatherhistorydata.error}
              date={weatherhistorydata.date}
              Data={weatherhistorydata.weatherhistoryData}
              />
      </div>
        );
      }
    }
  const mapStateToProps = state =>{
    return {weatherhistorydata: state.historyReducer};
  }
  export default connect(mapStateToProps)(History);



