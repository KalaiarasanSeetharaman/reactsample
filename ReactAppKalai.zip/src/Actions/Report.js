import * as weatherAPI from '../Services/Index';
/***
 Action For Getting List from getReportWeather via Api call and
 Send to reducer for store changes
 ***/
export const initateReport = () => {
    return {
        type: 'SENDING_REQUEST',
        error: ""
    };
  };


export const receviedReport = (historydata) => {
    return {
        type: 'RECEVIED_LISTS',
        count:historydata.cnt,
        weatherhistoryData:historydata.list,
        error: ""
    };
  };
  
  /***
   Action for failure when api call fails
   ***/
  export const failure = (error) => {
    return {
      type: 'SENDING_REQUEST_FAILED',
      error: 'Please provide Valid Input!',
      count:0
    };
  };
  
  /***
   Action for api calls
   ***/
  export const getReportWeather = (Api_Key) => {
    return (dispatch, getState) => {
      weatherAPI.getCityWeatherReport(Api_Key)
              .then(
                  res => { 
                      console.log(res);
                      if(res.cod !== 200 && res.cod !== "200"){
                        dispatch(failure(res));
                      }else{
                        dispatch(receviedReport(res));
                      }
                  },
                  error => {
                      dispatch(failure(error));
                  }
              );
  
    };
  };