import * as weatherAPI from '../Services/Index';
/***
 Action For Getting List from getCityWeather via Api call and
 Send to reducer for store changes
 ***/
export const receviedlists = (weatherdata) => {
  return {
    type: 'RECEVIED_LISTS',
    temperature: weatherdata.main.temp,
    city: weatherdata.name,
    humidity: weatherdata.main.humidity,
    country: weatherdata.sys.country,
    error: ''
  };
};

/***
 Action for failure when api call fails
 ***/
export const failure = (error) => {
  return {
    type: 'SENDING_REQUEST_FAILED',
    error: 'Please provide Valid Input!'
  };
};

/***
 Action for api calls
 ***/
export const getWeatherForCity = (city,Api_Key) => {
  return (dispatch, getState) => {
    weatherAPI.getCityWeather(city,Api_Key)
            .then(
                res => { 
                    console.log(res);
                    if(res.cod !== 200 && res.cod !== "200"){
                      dispatch(failure(res));
                    }else{
                      dispatch(receviedlists(res));
                    }
                },
                error => {
                    dispatch(failure(error));
                }
            );

  };
};

