/****
Requiring Redux ,
Redux Thunk for  Api Calls as Middleware for Redux
Reduc Logger is log in browser console for developer purpose
****/
import {combineReducers,createStore,applyMiddleware,compose} from 'redux';
import thunk from "redux-thunk";
import weatherReducer from '../Reducers/Index.js';
import historyReducer from '../Reducers/Weatherhistory.js';
import reportReducer from '../Reducers/Report.js';


import logger from "redux-logger";
import promise from "redux-promise-middleware";
/***Here we are creating one store for our application by combining all reducer**/
export var configure = (initialState) => {
  var reducer = combineReducers({
    weatherReducer: weatherReducer,
    historyReducer: historyReducer,
    reportReducer: reportReducer

  });

  var store = createStore(reducer,initialState, compose(
  	applyMiddleware(promise(),thunk,logger),
    window.devToolsExtension ? window.devToolsExtension() : f => f
  ));

  return store;
}
