/***Importing Axios Lib for Async Method For Getting Data From Api***/
import * as axios from 'axios';

/***Api Url***/


const APP_URL = "http://api.openweathermap.org/data/2.5/";

//http://history.openweathermap.org/data/2.5/history/city?id={id}&type=hour&start={start}&end={end}
//var requestUrl = `${APP_URL}history/city?q=Bangalore,IND&appid=${Api_Key}&type=hour&start=1369728000&end=1369789200`;
export const getCityWeather = function(city,Api_Key){
      var requestUrl = `${APP_URL}weather?q=${city}&appid=${Api_Key}&units=metric`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (response) {
        return response;
      });
};

export const getCityWeatherHistory = function(city,Api_Key){
      var requestUrl = `${APP_URL}forecast?q=${city}&appid=${Api_Key}&units=metric`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (response) {
        return response;
      });
};

export const getCityWeatherReport = function(Api_Key){
      var requestUrl = `${APP_URL}forecast?q=Bangalore&appid=${Api_Key}&units=metric`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (response) {
        return response;
      });
};